### Prova singola 4H 28/03/2022 su form multiple, classi, liste e utilizzo di GIT
Dato lo scheletro di programma del progetto corrente completarlo con le parti mancanti.

Per il funzionamento complessivo del programma � possibile vedere il video (gif) nella sottocartella Doc

## Punti di partenza 1

## Depositi necessari (tot 3 punti) su Git con la descrizione sotto indicata al completamento dello sviluppo o indicando la frase "Commit delle ore " + orario se per scadenza oraria
Ogni 10 minuti con tolleranza di 2 minuti e cmq :
- All'inizio dello sviluppo subito dopo aver aperto Visual Studio sul progetto di partenza del prof; repo pubblica con nome uguale a quella del progetto di partenza
- (1) aggiungere l'articolo creato dai dati di frmArticoli nella lista articoli
- (2) aggiungere visualizzazione articoli inseriti nella listbox
- (3) aggiungere visualizzazione dettaglio articolo nelle label
- (4) creazione lista articoli
- (5) aggiungere attributi privati dei dati inseriti nella frmArticoli
- (6) aggiungere property di sola lettura dei dati inseriti nella frmArticoli per l'utilizzo in frmMain
- (7) passaggio all' attributo/property dei dati inseriti nella frmArticoli con controllo di valorizzazione del dato
- (8) aggiungere attributi privati di Articolo
- (9) aggiungere property di sola lettura dei dati necessari all'esterno di Articolo
- (10) impostazione costruttore classe Articolo come utilizzato da frmMain  
Tot. 5 punti

### Consegnare su classroom lo zip scaricato dalla propria repo su github modificando nello zip al posto di Prof il proprio CognomeNome per salvare su classroom il proprio lavoro e indicare nella consegna l'url della repo pubblica con il nome indicato (.git) perch� verr� corretto il file ri-scaricato da github  
Punti 1